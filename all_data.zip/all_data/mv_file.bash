
cat   CASF-2016.txt  | while read line

do

	mv    ../$line*  .
	cp  -r   ../core_2013/$line*  .

done
