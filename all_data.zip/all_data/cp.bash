
for name in   ????.dat
do
base=${name%.dat}
cp -r  "../../all_pdb_all_n_test_check_final_2022_6_vec_30xx_cutoff0.8/all_data/"$base'_poc.pdb'  .

done
